package com.example.calculator1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonAdd, buttonSub, buttonMul, buttonDiv;
    EditText editTextN1, editTextN2;
    TextView textView;
    int num1, num2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            buttonAdd = findViewById(R.id.add);
            buttonSub = findViewById(R.id.sub);
            buttonMul = findViewById(R.id.mul);
            buttonDiv = findViewById(R.id.div);
            editTextN1 = findViewById(R.id.number1);
            editTextN2 = findViewById(R.id.number2);
            textView = findViewById(R.id.answer);

            buttonAdd.setOnClickListener(this);
            buttonSub.setOnClickListener(this);
            buttonMul.setOnClickListener(this);
            buttonDiv.setOnClickListener(this);


            return insets;
        });
    }

    public int getIntFromEditText(EditText editText) {
        if (editText.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return 0;
        } else {
            return Integer.parseInt(editText.getText().toString());
        }
    }


    @Override
    public void onClick(View view) {
        num1 = getIntFromEditText(editTextN1);
        num2 = getIntFromEditText(editTextN2);
        int id = view.getId();

        if (id == R.id.add) {
            textView.setText("Answer = " + (num1 + num2));
        } else if (id == R.id.sub) {
            textView.setText("Answer = " + (num1 - num2));
        } else if (id == R.id.mul) {
            textView.setText("Answer = " + (num1 * num2));
        } else if (id == R.id.div) {
            // To prevent division by zero, you should add a check
            if (num2 == 0) {
                Toast.makeText(this, "Cannot divide by zero", Toast.LENGTH_SHORT).show();
                textView.setText("Answer = undefined");
            } else {
                textView.setText("Answer = " + ((float) num1 / (float) num2));
            }
        }
    }
}